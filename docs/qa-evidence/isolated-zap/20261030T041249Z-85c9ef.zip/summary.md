# Actual QA execution

Execution date (UTC): 2026-10-30T04:12:49.514283+00:00
Commit: `c0c126f13d61f75e6564b91da5f73eabfd68a703`
Working tree modified: True
Exact source fingerprint: `13af9c20404d3239d4c5327edcb5e1fd6c9c0eb2af8148d5f90a00bff675393f` (see manifest.json)

| Stage | Status | Evidence / reason |
|---|---|---|
| backend | Passed | backend.log |
| qa-tools | Passed | qa-tools.log |
| frontend-build | Passed | frontend-build.log |
| isolated-services | Passed | server.log |
| selenium | Failed | selenium.log |
| security | Passed | security.log |
| zap | Warning | ['zap.html', 'zap.json', 'security-findings.json'] |

Executed case outcomes: {'Passed': 451, 'Failed': 1}

Mock boundaries: LLM, GitHub, Docker and shell. Authentication, RBAC, database, trained classifier, orchestration, approvals and audit routes are real.
Stored model metrics are historical artifacts; this run does not retrain or re-evaluate model accuracy.

See traceability.md for individual test outcomes. Blocked stages are not passing evidence.
