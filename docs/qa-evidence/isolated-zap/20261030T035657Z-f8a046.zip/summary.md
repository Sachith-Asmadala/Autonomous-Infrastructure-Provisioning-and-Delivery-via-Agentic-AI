# Actual QA execution

Execution date (UTC): 2026-10-30T03:56:57.215679+00:00
Commit: `6bd36969350b28121a73005dff3d7d935c66a50a`
Working tree modified: True
Exact source fingerprint: `3a83c5e225b19927b80c83ffe521118a696d1fb6207ee8fad18cffeb566dac9c` (see manifest.json)

| Stage | Status | Evidence / reason |
|---|---|---|
| frontend-build | Passed | frontend-build.log |
| isolated-services | Passed | server.log |
| security | Passed | security.log |
| zap | Warning | ['zap.html', 'zap.json', 'security-findings.json'] |

Executed case outcomes: {'Passed': 12}

Mock boundaries: LLM, GitHub, Docker and shell. Authentication, RBAC, database, trained classifier, orchestration, approvals and audit routes are real.
Stored model metrics are historical artifacts; this run does not retrain or re-evaluate model accuracy.

See traceability.md for individual test outcomes. Blocked stages are not passing evidence.
