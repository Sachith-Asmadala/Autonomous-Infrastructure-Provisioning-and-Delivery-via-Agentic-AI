# Actual QA execution

Execution date (UTC): 2026-10-30T03:42:36.768294+00:00
Commit: `c0c126f13d61f75e6564b91da5f73eabfd68a703`
Working tree modified: False
Exact source fingerprint: `15495a327bd903ec850090215ab58b290f2dd6366ab238bfdf9d9eb4a3529666` (see manifest.json)

| Stage | Status | Evidence / reason |
|---|---|---|
| backend | Passed | backend.log |
| qa-tools | Passed | qa-tools.log |

Executed case outcomes: {'Passed': 378}

Mock boundaries: LLM, GitHub, Docker and shell. Authentication, RBAC, database, trained classifier, orchestration, approvals and audit routes are real.
Stored model metrics are historical artifacts; this run does not retrain or re-evaluate model accuracy.

See traceability.md for individual test outcomes. Blocked stages are not passing evidence.
