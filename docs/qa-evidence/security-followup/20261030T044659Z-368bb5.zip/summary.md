# Actual QA execution

Execution date (UTC): 2026-10-30T04:47:00.296702+00:00
Commit: `c0c126f13d61f75e6564b91da5f73eabfd68a703`
Working tree modified: True
Exact source fingerprint: `4b4c861911975b2a26c33ee529d164d7e15520d9aa5cab2a40901646b9badeec` (see manifest.json)

| Stage | Status | Evidence / reason |
|---|---|---|
| frontend-build | Passed | frontend-build.log |
| isolated-services | Passed | server.log |
| security | Passed | security.log |
| zap | Warning | ['zap.html', 'zap.json', 'security-findings.json'] |

Executed case outcomes: {'Passed': 12}

Mock boundaries: LLM, GitHub, Docker and shell. Authentication, RBAC, database, trained classifier, orchestration, approvals and audit routes are real.
Stored model metrics are historical artifacts; this run does not retrain or re-evaluate model accuracy.

See traceability.md for individual test outcomes. Blocked stages are not passing evidence.
