# Actual QA execution

Execution date (UTC): 2026-10-30T04:40:46.349089+00:00
Commit: `c0c126f13d61f75e6564b91da5f73eabfd68a703`
Working tree modified: True
Exact source fingerprint: `f41c0075f458ac10fcb94d43f5cefd1fdbda8a5ad30bcb58af8ad3c6ada29cf4` (see manifest.json)

| Stage | Status | Evidence / reason |
|---|---|---|
| backend | Passed | backend.log |
| qa-tools | Passed | qa-tools.log |
| frontend-build | Passed | frontend-build.log |
| isolated-services | Passed | server.log |
| selenium | Passed | selenium.log |
| security | Passed | security.log |
| zap | Not Executed | Explicit --no-zap option. |

Executed case outcomes: {'Passed': 454}

Mock boundaries: LLM, GitHub, Docker and shell. Authentication, RBAC, database, trained classifier, orchestration, approvals and audit routes are real.
Stored model metrics are historical artifacts; this run does not retrain or re-evaluate model accuracy.

See traceability.md for individual test outcomes. Blocked stages are not passing evidence.
